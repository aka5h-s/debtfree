# NeoPop Example

A sample app demonstrating the use of the neopop package.
