## 1.0.2 
* Increase version support for dart & flutter

## 1.0.1

* README update

## 1.0.0

* **NEOPOP** initial release, CRED's inbuilt library for using neopop components in your app
